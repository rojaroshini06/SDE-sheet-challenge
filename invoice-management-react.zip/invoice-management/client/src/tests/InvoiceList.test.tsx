import React from 'react';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import InvoiceList from '../components/InvoiceList';
import { fetchInvoices, submitPayment } from '../services/invoiceService';
import { Invoice } from '../interfaces/invoice';

jest.mock('../services/invoiceService');

const mockInvoices: Invoice[] = [
  {
    reference: 'INV001',
    amount: 100,
    paidAmount: 50,
    status: 'PARTIALLY_PAID',
    createdAt: '2023-09-01T00:00:00Z',
    dueDate: '2023-10-01T00:00:00Z',
  },
  {
    reference: 'INV002',
    amount: 200,
    paidAmount: 0,
    status: 'NOT_PAID',
    createdAt: '2023-09-10T00:00:00Z',
    dueDate: '2023-10-10T00:00:00Z',
  },
];

(fetchInvoices as jest.Mock).mockResolvedValue({
  content: mockInvoices,
  totalPages: 1,
});

(submitPayment as jest.Mock).mockImplementation((reference, payment) => {
  return {
    reference,
    amount: payment + mockInvoices.find(inv => inv.reference === reference)!.paidAmount,
    paidAmount: payment,
    status: payment + mockInvoices.find(inv => inv.reference === reference)!.paidAmount === 200 ? 'PAID' : 'PARTIALLY_PAID',
    createdAt: '2023-09-01T00:00:00Z',
    dueDate: '2023-10-01T00:00:00Z',
  };
});

describe('InvoiceList', () => {
  beforeEach(() => {
    window.alert = jest.fn();
  });

  test('renders loading state initially', async () => {
    render(<InvoiceList />);
    expect(screen.getByTestId('loading-message')).toHaveTextContent('Loading invoices...');
    await waitFor(() => expect(fetchInvoices).toHaveBeenCalled());
  });

  test('renders invoices after loading', async () => {
    render(<InvoiceList />);
    await waitFor(() => expect(screen.getByTestId('invoice-reference-INV001')).toBeInTheDocument());
    expect(screen.getByTestId('invoice-reference-INV001')).toHaveTextContent('INV001');
    expect(screen.getByText('50')).toBeInTheDocument();
    expect(screen.getByText('PARTIALLY PAID')).toBeInTheDocument();
    expect(screen.getByText('9/1/2023')).toBeInTheDocument();
    expect(screen.getByText('10/1/2023')).toBeInTheDocument();
  });

  test('displays error message when fetch fails', async () => {
    (fetchInvoices as jest.Mock).mockRejectedValueOnce(new Error('Failed to fetch invoices'));
    render(<InvoiceList />);
    await waitFor(() => {
      expect(screen.getByTestId('error-message')).toHaveTextContent('Error fetching invoices: Failed to fetch invoices');
    });
  });

  test('handles valid payment input', async () => {
    render(<InvoiceList />);
    await waitFor(() => expect(screen.getByTestId('invoice-reference-INV001')).toBeInTheDocument());
    const paymentInput = screen.getByTestId('payment-input-INV001');
    fireEvent.change(paymentInput, { target: { value: '25' } });
    expect(paymentInput).toHaveValue(25);
    const submitButton = screen.getByTestId('submit-button-INV001');
    expect(submitButton).not.toBeDisabled();
  });

  test('shows error for invalid payment input', async () => {
    render(<InvoiceList />);
    await waitFor(() => expect(screen.getByTestId('invoice-reference-INV001')).toBeInTheDocument());
    const paymentInput = screen.getByTestId('payment-input-INV001');
    fireEvent.change(paymentInput, { target: { value: '1000' } });
    await waitFor(() => expect(screen.getByTestId('error-message-INV001')).toHaveTextContent('Invalid payment amount'));
    const submitButton = screen.getByTestId('submit-button-INV001');
    expect(submitButton).toBeDisabled();
  });

  test('submits payment and updates the invoice', async () => {
    render(<InvoiceList />);
    await waitFor(() => expect(screen.getByTestId('invoice-reference-INV002')).toBeInTheDocument());
    const paymentInput = screen.getByTestId('payment-input-INV002');
    fireEvent.change(paymentInput, { target: { value: '200' } });
    const submitButton = screen.getByTestId('submit-button-INV002');
    fireEvent.click(submitButton); 
    await waitFor(() => {
      expect(screen.getByText('PAID')).toBeInTheDocument();
    });
  });
});
