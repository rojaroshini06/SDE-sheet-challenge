export interface Invoice {
    reference: string;
    amount: number;
    paidAmount: number;
    status: 'NOT_PAID' | 'PARTIALLY_PAID' | 'PAID';
    createdAt: string; 
    dueDate: string;  
  }