import { ApiResponse } from '../interfaces/ApiResponse';
import { apiClient } from '../utils/api';
import { Invoice } from '../interfaces/invoice';

const INVOICES_ENDPOINT = '/api/invoices'; // Relative path


export const fetchInvoices = async (page: number = 0, size: number = 5): Promise<ApiResponse> => {
  const response = await apiClient.get<ApiResponse>(`${INVOICES_ENDPOINT}?page=${page}&size=${size}`);
  return response.data;
};


export const submitPayment = async (reference: string, amount: number): Promise<Invoice> => {
  const response = await apiClient.post<Invoice>(`${INVOICES_ENDPOINT}/${reference}/pay`, {
    amount: amount.toString(),
  });
  return response.data;
};
