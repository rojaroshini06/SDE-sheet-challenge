import React, { useState, useEffect, ChangeEvent } from 'react';
import './invoiceList.css';
import { Invoice } from '../interfaces/invoice';

import { fetchInvoices, submitPayment } from '../services/invoiceService';

const PAGE_SIZE = 5;

const InvoiceList: React.FC = () => {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [paymentAmount, setPaymentAmount] = useState<Record<string, string>>({});
  const [isPaymentValid, setIsPaymentValid] = useState<Record<string, boolean>>({});
  const [hasUserInteracted, setHasUserInteracted] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [paymentError, setPaymentError] = useState<Record<string, string>>({});
  const [currentPage, setCurrentPage] = useState<number>(0);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [isSubmitting, setIsSubmitting] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const data = await fetchInvoices(currentPage, PAGE_SIZE);
        setInvoices(data.content);
        setTotalPages(data.totalPages);
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred';
        setError(errorMessage);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [currentPage]);

  const handlePaymentChange = (reference: string, value: string) => {
    const numericAmount = parseFloat(value);
    const invoice = invoices.find(inv => inv.reference === reference);

    if (!invoice) return;

    const remainingAmount = invoice.amount - invoice.paidAmount;

    setHasUserInteracted(prev => ({ ...prev, [reference]: true }));

    let isValid = true;
    if (isNaN(numericAmount) || value.trim() === '') {
      isValid = false;
    } else if (numericAmount > remainingAmount || numericAmount <= 0) {
      isValid = false;
    }

    setIsPaymentValid(prev => ({ ...prev, [reference]: isValid }));

    setPaymentAmount(prev => ({ ...prev, [reference]: value }));

    setPaymentError(prev => ({ ...prev, [reference]: '' }));
  };

  const handleSubmitPayment = async (invoice: Invoice) => {
    const paymentStr = paymentAmount[invoice.reference];
    const payment = parseFloat(paymentStr);
  
    if (isNaN(payment) || payment <= 0 || !isPaymentValid[invoice.reference]) {
      alert('Please enter a valid payment amount');
      return;
    }
  
    setIsSubmitting(prev => ({ ...prev, [invoice.reference]: true }));
  
    try {
      const updatedInvoice = await submitPayment(invoice.reference, payment);
      
      setInvoices(prevInvoices =>
        prevInvoices.map(inv =>
          inv.reference === updatedInvoice.reference ? updatedInvoice : inv
        )
      );
  
      setPaymentAmount(prev => ({ ...prev, [invoice.reference]: '' }));
      setIsPaymentValid(prev => ({ ...prev, [invoice.reference]: false }));
      setHasUserInteracted(prev => ({ ...prev, [invoice.reference]: false }));
      setPaymentError(prev => ({ ...prev, [invoice.reference]: '' }));
  
      alert(`Thanks for the payment of $${payment.toFixed(2)} towards invoice ${invoice.reference}!`);
      
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred';
      setPaymentError(prev => ({ ...prev, [invoice.reference]: errorMessage }));
    } finally {
      setIsSubmitting(prev => ({ ...prev, [invoice.reference]: false }));
    }
  };
  

  const renderPagination = () => (
    <div className="pagination">
      <button
        onClick={() => setCurrentPage(prev => Math.max(prev - 1, 0))}
        disabled={currentPage === 0}
      >
        Previous
      </button>
      <span>
        Page {currentPage + 1} of {totalPages}
      </span>
      <button
        onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages - 1))}
        disabled={currentPage >= totalPages - 1}
      >
        Next
      </button>
    </div>
  );

  if (loading) {
    return <div className="loading" data-testid="loading-message">Loading invoices...</div>;
  }

  if (error) {
    return <div className="error" data-testid="error-message">Error fetching invoices: {error}</div>;
  }

  return (
    <div className="invoice-list">
      <h1>Invoice List</h1>
      <table>
        <thead>
          <tr>
            <th>Reference</th>
            <th>Amount</th>
            <th>Paid Amount</th>
            <th>Status</th>
            <th>Created At</th>
            <th>Due Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {invoices.map(invoice => (
            <tr key={invoice.reference}>
              <td data-testid={`invoice-reference-${invoice.reference}`}>{invoice.reference}</td>
              <td>{invoice.amount}</td>
              <td>{invoice.paidAmount}</td>
              <td>{invoice.status.replace('_', ' ')}</td>
              <td>{new Date(invoice.createdAt).toLocaleDateString()}</td>
              <td>{new Date(invoice.dueDate).toLocaleDateString()}</td>
              <td>
                {invoice.status !== 'PAID' && (
                  <div className="payment-action">
                    <input
                      type="number"
                      data-testid={`payment-input-${invoice.reference}`}
                      value={paymentAmount[invoice.reference] || ''}
                      onChange={(e: ChangeEvent<HTMLInputElement>) =>
                        handlePaymentChange(invoice.reference, e.target.value)
                      }
                      placeholder="Enter payment"
                      min="0"
                      max={invoice.amount - invoice.paidAmount}
                      step="1"
                      required
                    />
                    {hasUserInteracted[invoice.reference] && !isPaymentValid[invoice.reference] && paymentAmount[invoice.reference]?.trim() !== '' && (
                      <small className="error-message" data-testid={`error-message-${invoice.reference}`}>
                        Invalid payment amount
                      </small>
                    )}
                    {paymentError[invoice.reference] && (
                      <small className="error-message" data-testid={`payment-error-${invoice.reference}`}>
                        {paymentError[invoice.reference]}
                      </small>
                    )}
                    <button
                      data-testid={`submit-button-${invoice.reference}`}
                      onClick={() => handleSubmitPayment(invoice)}
                      disabled={
                        !isPaymentValid[invoice.reference] ||
                        !paymentAmount[invoice.reference]?.trim() ||
                        isSubmitting[invoice.reference]
                      }
                    >
                      {isSubmitting[invoice.reference] ? 'Submitting...' : 'Submit'}
                    </button>
                  </div>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {renderPagination()}
    </div>
  );
};

export default InvoiceList;
